Just Another Regular Person Getting Lots Of Cat food 
Credits::
James Marcil
Michael Weiler [SpaceOrca]

Controls::
wasd = move
esc = quit